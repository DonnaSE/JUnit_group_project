
Team of two
1. Mohammed Al Aadhami
2. Raghad Safauldeen

We have the file named: Printtokens2Test.java that contains the source code of our test cases. It can be executed in Eclipse using the run for coverage button.

We have arranged the source code in Eclipse using: Source --> format, so the numbers are slightly different than the source code provided by the professor. We included the used source code in the folder we submitted.

We used the Jacoco built-in in the newest version of Eclipse 2019 to find the code coverage.

Three zipped files for code coverage are included:

1. codecoverage_all_with_main: contains the whole source code of the test cases and no part is commented out.

2. codecoverage_all_withouth_main: contains all the test cases except test case for main which is commented out alone.

3. codecoverage_only_main: contains the test case for main only and every other test case is commented out. 

Also, 4 text files were included in the folder and were used in our test cases:

1. backt.txt
2. empty.txt
3. str.txt
4. str2.txt

